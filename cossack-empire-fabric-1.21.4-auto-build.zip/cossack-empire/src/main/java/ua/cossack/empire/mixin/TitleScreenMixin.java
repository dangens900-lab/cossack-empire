package ua.cossack.empire.mixin;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.TitleScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ua.cossack.empire.client.CossackTitleScreen;

@Mixin(TitleScreen.class)
public abstract class TitleScreenMixin {
    @Inject(method = "init", at = @At("TAIL"))
    private void cossackEmpire$openCustomMenu(CallbackInfo ci) {
        MinecraftClient.getInstance().setScreen(new CossackTitleScreen());
    }
}
