package ua.cossack.empire.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.client.gui.screen.world.SelectWorldScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public final class CossackTitleScreen extends Screen {
    private static final Identifier BACKGROUND = Identifier.of(
            "cossack_empire", "textures/gui/title_background.png");

    public CossackTitleScreen() {
        super(Text.literal("Козацька імперія"));
    }

    @Override
    protected void init() {
        int buttonWidth = Math.min(250, this.width - 40);
        int buttonHeight = 24;
        int gap = 7;
        int x = (this.width - buttonWidth) / 2;
        int y = this.height / 2 - 4;

        addDrawableChild(ButtonWidget.builder(Text.literal("⚔  Нова гра"), button ->
                MinecraftClient.getInstance().setScreen(new SelectWorldScreen(this)))
                .dimensions(x, y, buttonWidth, buttonHeight).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("▶  Продовжити гру"), button ->
                MinecraftClient.getInstance().setScreen(new SelectWorldScreen(this)))
                .dimensions(x, y + (buttonHeight + gap), buttonWidth, buttonHeight).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("▣  Завантажити гру"), button ->
                MinecraftClient.getInstance().setScreen(new SelectWorldScreen(this)))
                .dimensions(x, y + 2 * (buttonHeight + gap), buttonWidth, buttonHeight).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("⚙  Налаштування"), button ->
                MinecraftClient.getInstance().setScreen(new OptionsScreen(this, MinecraftClient.getInstance().options)))
                .dimensions(x, y + 3 * (buttonHeight + gap), buttonWidth, buttonHeight).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Вийти з гри"), button ->
                MinecraftClient.getInstance().scheduleStop())
                .dimensions(x, y + 4 * (buttonHeight + gap), buttonWidth, buttonHeight).build());
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        context.drawTexture(RenderLayer::getGuiTextured, BACKGROUND,
                0, 0, 0.0F, 0.0F, this.width, this.height, 1536, 1024);

        int panelWidth = Math.min(330, this.width - 20);
        int panelLeft = (this.width - panelWidth) / 2;
        context.fill(panelLeft, 8, panelLeft + panelWidth, 82, 0xA9000000);
        context.fill(panelLeft + 3, 11, panelLeft + panelWidth - 3, 79, 0x663C1B0B);
        context.drawCenteredTextWithShadow(this.textRenderer,
                Text.literal("⚜ КОЗАЦЬКА ⚜"), this.width / 2, 20, 0xFFFFD36A);
        context.drawCenteredTextWithShadow(this.textRenderer,
                Text.literal("ІМПЕРІЯ"), this.width / 2, 40, 0xFFFFC84A);
        context.drawCenteredTextWithShadow(this.textRenderer,
                Text.literal("Козацька держава починається тут"), this.width / 2, 65, 0xFFF4E4C5);
        super.render(context, mouseX, mouseY, delta);
        context.drawTextWithShadow(this.textRenderer, Text.literal("Козацька імперія • Alpha 0.1.0"),
                8, this.height - 14, 0xFFE9D7B0);
    }

    @Override
    public boolean shouldCloseOnEsc() {
        return false;
    }
}
