package ua.cossack.empire.client;

import net.fabricmc.api.ClientModInitializer;

public final class CossackEmpireClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        // The title screen is installed by TitleScreenMixin.
    }
}
